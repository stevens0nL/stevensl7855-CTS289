# Design System Specification: The Scholastic Atelier

## 1. Overview & Creative North Star
This design system is built to transform academic tracking from a chore into a prestigious pursuit. The **Creative North Star** for this system is **"The Scholastic Atelier."** 

We are moving away from the "SaaS dashboard" aesthetic. Instead, we are leaning into a high-end editorial experience—think of a premium academic journal met with a modern architectural portfolio. We achieve this through:
*   **Intentional Asymmetry:** Breaking the rigid 12-column grid to allow for "breathing moments" where white space drives focus.
*   **Tonal Depth:** Replacing harsh lines with sophisticated layering of greens and off-whites.
*   **Typographic Authority:** Using dramatic scale shifts between Manrope headlines and Inter data points to create a sense of importance and clarity.

The goal is **motivation through prestige**. When a student sees their "A" grade, it shouldn't just be a letter; it should feel like a reward.

---

## 2. Color & Surface Philosophy
The palette is rooted in a deep, scholarly green, balanced by "Paper" surfaces that reduce eye strain during long study sessions.

### The "No-Line" Rule
**Explicit Instruction:** Designers are prohibited from using 1px solid borders to section content. Boundaries must be defined solely through:
1.  **Background Shifts:** Placing a `surface-container-lowest` card on a `surface-container-low` background.
2.  **Tonal Transitions:** Using the hierarchy of `surface-container` tiers to denote nesting.

### Surface Hierarchy & Nesting
Treat the UI as physical layers of fine paper. 
*   **Base:** `surface` (#f8faf3).
*   **Sections:** `surface-container-low` (#f2f4ed).
*   **Interactive Cards:** `surface-container-lowest` (#ffffff).
*   **In-Card Details:** `surface-container-high` (#e7e9e2).

### The "Glass & Gradient" Rule
To escape the "flat" look, main CTAs and hero progress moments must use subtle gradients. Transition from `primary` (#134718) to `primary_container` (#2C5F2D). For floating navigation or "Quick Look" modals, use **Glassmorphism**: a semi-transparent `surface` color with a 20px backdrop-blur.

---

## 3. Typography
We utilize a dual-typeface system to balance institutional authority with modern legibility.

*   **Manrope (The Voice):** Used for `display`, `headline`, and `title` roles. It feels architectural and confident. Use `display-lg` (3.5rem) for high-impact motivational stats (e.g., your current GPA).
*   **Inter (The Data):** Used for `body` and `label` roles. Inter’s tall x-height ensures that complex grade breakdowns remain legible at small sizes.

**Editorial Tip:** Use `label-md` in all-caps with 5% letter spacing for category headers to create a "premium magazine" feel.

---

## 4. Elevation & Depth
Hierarchy is achieved through **Tonal Layering**, not structural scaffolding.

*   **The Layering Principle:** Depth is "stacked." An "A" Grade badge should sit on a `surface-container-highest` element, which sits on a `surface-container-low` section.
*   **Ambient Shadows:** When an element must "float" (like a FAB or a Tooltip), use a 32px blur with 4% opacity. The shadow color should be a tinted version of `on-surface` (#191c18), never pure black.
*   **The Ghost Border:** If a boundary is strictly required for accessibility, use `outline-variant` (#c1c9bc) at **15% opacity**. It should be felt, not seen.

---

## 5. Components

### Buttons
*   **Primary:** Rounded `lg` (1rem). Background: Gradient from `primary` to `primary_container`. Text: `on_primary`. 
*   **Secondary:** `surface-container-high` background. No border. Text: `primary`.
*   **Action Chips:** Use `full` (9999px) roundedness. These should feel like smooth pebbles.

### Vibrant Progress Bars
Progress bars are the "soul" of this system. 
*   **Track:** `surface-container-highest`.
*   **Indicator:** A linear gradient from `secondary` (#735c00) to `primary` (#134718). This creates a "growth" metaphor, moving from a spark of gold to the deep green of success.
*   **Motion:** Always animate progress bars from 0 on load with a "Slow-In, Fast-Out" easing.

### Grade Indicators (The "Monogram" Component)
Grades (A, B, C) are not just text. 
*   **Style:** `headline-lg` (Manrope).
*   **Container:** A soft, oversized circle or "squircle" (`xl` roundedness) using `tertiary_container` for high-performing grades to provide a vibrant contrast to the primary green.

### Cards & Lists
*   **Constraint:** Zero divider lines. 
*   **Spacing:** Use the `1.5rem` (xl) spacing scale to separate list items. 
*   **Interaction:** On hover, a card should transition from `surface-container-lowest` to `surface-bright` and gain an Ambient Shadow.

### Academic Inputs
*   **Field:** `surface-container-low` background with a `sm` (0.25rem) bottom-only `primary` accent on focus.
*   **Labels:** Always use `label-md` positioned 8px above the input, never placeholder text alone.

---

## 6. Do’s and Don’ts

### Do
*   **Do** use asymmetrical layouts (e.g., a large GPA display on the left with a thin column of recent grades on the right).
*   **Do** use `surface-dim` for "empty state" illustrations to maintain the sophisticated mood.
*   **Do** embrace wide margins. The content needs room to be "studied."

### Don’t
*   **Don’t** use pure black (#000000) for text. Use `on_surface` (#191c18).
*   **Don’t** use 1px borders to separate dashboard modules. Use white space or a background color shift.
*   **Don’t** use vibrant "Success Green" (#00FF00). Only use the specified `primary` (#134718) to maintain the premium feel.
*   **Don’t** crowd the interface. If a screen feels busy, increase the spacing scale.